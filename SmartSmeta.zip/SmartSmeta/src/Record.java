public class Record {
    int id;
    String brand;
    String category;
    String creator;
    String modelName;
    String specification;
    int price;

    int count;


}
