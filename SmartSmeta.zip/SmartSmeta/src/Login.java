import javax.swing.*;
import javax.swing.plaf.DimensionUIResource;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Login extends JFrame {
    private JPanel panelMain;
    private JPanel panelButton;
    private JPanel panelLabel;
    private JLabel loginLabel;
    private JLabel passwordLabel;
    private JButton enterButton;
    private JButton cancelButton;
    private JButton registerButton;
    private JTextField loginField;
    private JTextField passwordField;
    public Login(){
        this.setSize(300, 200);
        this.setLocationRelativeTo(null);
        this.setTitle("Вход");

        panelMain = new JPanel();
        panelMain.setLayout(new BoxLayout(panelMain, BoxLayout.Y_AXIS));

        GridBagLayout layout = new GridBagLayout();
        panelLabel = new JPanel(layout);
        GridBagConstraints constraints = new GridBagConstraints();
        panelMain.add(panelLabel);

        loginLabel = new JLabel("Логин");
        constraints.weightx = 0.3;
        constraints.fill = GridBagConstraints.NONE;
        constraints.gridx = 0;
        constraints.gridy = 0;
        panelLabel.add(loginLabel, constraints);

        passwordLabel = new JLabel("Пароль");
        constraints.weightx = 0.3;
        constraints.insets = new Insets(10, 0, 0, 0);
        constraints.fill = GridBagConstraints.NONE;
        constraints.gridx = 0;
        constraints.gridy = 1;
        panelLabel.add(passwordLabel, constraints);

        panelButton = new JPanel();
        panelButton.setLayout(new BoxLayout(panelButton, BoxLayout.X_AXIS));

        loginField = new JTextField();
        loginField.setColumns(10);
        constraints.weightx = 0.7;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 0;
        panelLabel.add(loginField, constraints);

        passwordField = new JTextField();
        passwordField.setColumns(10);
        constraints.insets = new Insets(10, 0, 0, 0);
        constraints.weightx = 0.7;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 1;
        panelLabel.add(passwordField, constraints);

        enterButton = new JButton("Войти");
        enterButton.setAlignmentY(Component.BOTTOM_ALIGNMENT);
        enterButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
        registerButton = new JButton("Зарегистрироваться");
        registerButton.setAlignmentY(Component.BOTTOM_ALIGNMENT);
        registerButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
        cancelButton = new JButton("Отмена");
        cancelButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
        cancelButton.setAlignmentY(Component.BOTTOM_ALIGNMENT);
        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //обращение к базе данных, проверка
                String login = loginField.getText();
                String password = passwordField.getText();

                if (loginField.getText().length() == 0 || passwordField.getText().length()==0) {
                    JOptionPane.showMessageDialog(Login.this,
                            "Не введены пароль или логин",
                            "Ошибка",
                            JOptionPane.ERROR_MESSAGE);
                }
                    try {
                        String passwFromDB = getPasswordFromDB(login);
                        if (passwFromDB != null || passwFromDB.equals(password)) {
                            //Если все данные совпадают, то открывается гл. форма
                            Main frm = new Main();
                            frm.setVisible(true);
                            dispatchEvent(new WindowEvent(Login.this, WindowEvent.WINDOW_CLOSING));

                        } else {
                            JOptionPane.showMessageDialog(Login.this,
                                    "Введен неверный пароль или логин",
                                    "Ошибка",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(Login.this,
                                "Ошибка подключения к базе данных",
                                "Ошибка",
                                JOptionPane.ERROR_MESSAGE);
                    }

            }
        });
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //отправляет на форму с регистрацией
                Register reg = new Register();
                reg.setVisible(true);
                dispatchEvent(new WindowEvent(Login.this, WindowEvent.WINDOW_CLOSING));
            }
        });
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //закрывает программу
                System.exit(0);
            }
        });

        panelButton.add(enterButton);
        panelButton.add(registerButton);
        panelButton.add(cancelButton);
        panelMain.add(panelButton);

        this.add(panelMain);
    }

    public String getPasswordFromDB(String login) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        String query = "SELECT * FROM users WHERE login = '" + login + "';";
        Connection con = MyDB.getCon();
        if (con != null) {
            Statement st = null;
                st = con.createStatement();
                ResultSet result = st.executeQuery(query);
                if (result.next()) {
                    int id = result.getInt(1);
                    String user = result.getString(2);
                    String password = result.getString(3);
                    System.out.println(id + " " + user + " " + password);
                    return password;
                }
        }
        return null;
    }
    public static void main(String[] args){
        Login log = new Login();
        log.setVisible(true);
    }
}
