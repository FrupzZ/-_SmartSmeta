import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main extends JFrame {
    private JButton openBinButton;
    private JButton addBinButton;
    private JPanel panelMain;
    private JPanel panelButton;
    private JPanel panelTable;
    private JTable table;
    public Main(){
        this.setSize(1280, 800);
        this.setLocationRelativeTo(null);
        this.setTitle("SmartSmeta");
        panelMain = new JPanel();
        BorderLayout borderLayout = new BorderLayout();
        panelMain.setLayout(borderLayout);

        panelButton = new JPanel();
        panelButton.setLayout(new BoxLayout(panelButton, BoxLayout.Y_AXIS));


        addBinButton = new JButton("Добавить в корзину");
        addBinButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        addBinButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //добавляет выбранные продукты в корзину
                int row = table.getSelectedRow();
                //int col = table.getSelectedColumn();
                if(row >=0) {
                    Record record = MyDB.bin.get(table.getValueAt(row, 0));
                    if (record == null) {
                        record = new Record();
                        record.id = (int) table.getValueAt(row, 0);
                        record.brand = (String) table.getValueAt(row, 1);
                        record.category = (String) table.getValueAt(row, 2);
                        record.creator = (String) table.getValueAt(row, 3);
                        record.modelName = (String) table.getValueAt(row, 4);
                        record.specification = (String) table.getValueAt(row, 5);
                        record.price = (int) table.getValueAt(row, 6);
                        record.count = 0;
                    }
                    record.count += 1;
                    MyDB.bin.put(record.id, record);
                    System.out.print(row + " " + record.id + " ");
                    System.out.println(record.brand);
                }else{
                    JOptionPane.showMessageDialog(Main.this,
                            "Вы не выбрали товар",
                            "Ошибка",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        openBinButton = new JButton("Открыть корзину");
        openBinButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        openBinButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Bin b = new Bin();
                setVisible(false);
                b.setVisible(true);
            }
        });

        Color bgColor = new Color(173, 216, 170);
        panelMain.setBackground(bgColor);

        panelButton.add(openBinButton);
        panelButton.add(addBinButton);
        panelMain.add(panelButton, BorderLayout.LINE_START);

        try {
            tableSmeta();
        }
        catch (Exception e) {
        }

        panelMain.add(panelTable, BorderLayout.CENTER);
        this.add(panelMain);
    }


    public void showDB (DefaultTableModel model) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException{
        String brand;
        String category;
        String creator;
        String modelName;
        String specification;
        int price;
        String query = "SELECT * FROM products;";
        Connection connect = MyDB.getCon();
        if (connect != null){
            Statement st = connect.createStatement();
            ResultSet result = st.executeQuery(query);
            while (result.next()){
                int id = result.getInt(1);
                brand = result.getString(2);
                category = result.getString(3);
                creator= result.getString(4);
                modelName = result.getString(5);
                specification = result.getString(6);
                price = result.getInt(7);
                model.addRow(new Object[] {id, brand, category, creator, modelName, specification, price});
            }
        }
        else{
            throw new SQLException();
        }
    }

    public void tableSmeta () throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        panelTable = new JPanel();
        DefaultTableModel model = new DefaultTableModel();
        String [] columns = {"ID", "Бренд", "Категория", "Производитель", "Модель", "Характеристики", "Цена"};
        model.setColumnIdentifiers(columns);
        table = new JTable();
        table.setModel(model);
        showDB(model);
        panelTable.setLayout(new BorderLayout());
        panelTable.add(new JScrollPane(table), BorderLayout.CENTER);
        panelTable.setVisible(true);
    }
}