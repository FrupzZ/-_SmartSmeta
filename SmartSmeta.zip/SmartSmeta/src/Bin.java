import com.itextpdf.text.*;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Map;

public class Bin extends JFrame {
    private JPanel panelMain;
    private JPanel panelButton;
    private JPanel panelTable;
    private JButton returnButton;
    private JButton pokupkaButton;
    private JButton plusButton;
    private JButton minusButton;
    private JTable table;
    private String filename = "";
    private JTextField fileNameField;
    private JLabel labelNameField;

    public Bin(){
        this.setSize(1280, 800);
        this.setLocationRelativeTo(null);
        this.setTitle("Корзина");
        String pdf = ".pdf";
        panelMain = new JPanel();
        BorderLayout borderLayout = new BorderLayout();
        panelMain.setLayout(borderLayout);

        panelButton = new JPanel();
        panelButton.setLayout(new BoxLayout(panelButton, BoxLayout.Y_AXIS));

        pokupkaButton = new JButton("Сформировать файл");
        pokupkaButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        pokupkaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //отсылает на покупку
                try {
                    filename = fileNameField.getText() + pdf;
                    if(filename.length()==0){
                        throw new FileNotFoundException();
                    }
                    String airalFont = "C:\\Windows\\Fonts\\Arial.ttf";
                    String timesNewFont = "C:\\Windows\\Fonts\\Times.ttf";
                    Document doc = new Document();
                    PdfWriter.getInstance(doc, new FileOutputStream(filename));
                    doc.open();
                    //Font arial32 = FontFactory.getFont(FontFactory.COURIER, "CP1251", 16, BaseColor.BLACK);
                    BaseFont arial = BaseFont.createFont(airalFont, "cp1251", BaseFont.EMBEDDED);
                    BaseFont timesNew = BaseFont.createFont(timesNewFont, "cp1251", BaseFont.EMBEDDED);
                    Font arial32 = new Font(arial, 32, Font.BOLD);
                    Font arial16 = new Font(arial, 16, Font.BOLD);
                    Font trn14 = new Font(timesNew, 14, Font.BOLD);
                    Paragraph title = new Paragraph("Счет:", arial32);
                    title.setAlignment(Element.ALIGN_CENTER);
                    title.setSpacingAfter(32);
                    doc.add(title);
                    PdfPTable table = new PdfPTable(6);
                    PdfPCell cell1 = new PdfPCell(new Paragraph("ID", arial16));
                    PdfPCell cell2 = new PdfPCell(new Paragraph("Бренд", arial16));
                    PdfPCell cell3 = new PdfPCell(new Paragraph("Категория", arial16));
                    PdfPCell cell4 = new PdfPCell(new Paragraph("Модель", arial16));
                    PdfPCell cell5 = new PdfPCell(new Paragraph("Цена", arial16));
                    PdfPCell cell6 = new PdfPCell(new Paragraph("Количество", arial16));
                    table.addCell(cell1);
                    table.addCell(cell2);
                    table.addCell(cell3);
                    table.addCell(cell4);
                    table.addCell(cell5);
                    table.addCell(cell6);
                    float total = 0;
                    for(Map.Entry<Integer, Record> entry: MyDB.bin.entrySet()){
                        Record record = entry.getValue();
                        cell1 = new PdfPCell(new Paragraph(String.valueOf(record.id), trn14));
                        cell2 = new PdfPCell(new Paragraph(record.brand, trn14));
                        cell3 = new PdfPCell(new Paragraph(record.category, trn14));
                        cell4 = new PdfPCell(new Paragraph(record.modelName, trn14));
                        cell5 = new PdfPCell(new Paragraph(String.valueOf(record.price), trn14));
                        cell6 = new PdfPCell(new Paragraph(String.valueOf(record.count), trn14));
                        total += record.price*record.count;
                        table.addCell(cell1);
                        table.addCell(cell2);
                        table.addCell(cell3);
                        table.addCell(cell4);
                        table.addCell(cell5);
                        table.addCell(cell6);
                    }
                    doc.add(table);

                    String totalStr = String.format("Итого: %.2f", total);
                    Font font2 = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.BLACK);
                    Paragraph paragraph2 = new Paragraph(totalStr, arial32);
                    paragraph2.setAlignment(Element.ALIGN_RIGHT);
                    doc.add(paragraph2);
                    doc.close();

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(Bin.this,
                            "Имя файла пустое или указано неправильно",
                            "Ошибка",
                            JOptionPane.ERROR_MESSAGE);
                }
                JOptionPane.showMessageDialog(Bin.this,
                        "Файл сформирован успешно",
                        "",
                        JOptionPane.INFORMATION_MESSAGE);
                }
        });

        returnButton = new JButton("Обратно к товарам");
        returnButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main main = new Main();
                setVisible(false);
                main.setVisible(true);
            }
        });

        plusButton = new JButton("+");
        plusButton.setAlignmentY(Component.CENTER_ALIGNMENT);
        plusButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        plusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = table.getSelectedRow();

                Record record = MyDB.bin.get(table.getValueAt(row, 0));
                record.count++;
                table.getModel().setValueAt(record.count, row, 5);
                MyDB.bin.put(record.id, record);
            }
        });

        minusButton = new JButton("-");
        minusButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        minusButton.setAlignmentY(Component.CENTER_ALIGNMENT);
        minusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = table.getSelectedRow();
                Record record = MyDB.bin.get(table.getValueAt(row, 0));
                record.count--;
                if(record.count == 0) {
                    int result = JOptionPane.showConfirmDialog(Bin.this,
                            "Вы точно хотите удалить этот продукт?",
                            "Подтверждение", JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE);
                    if (result == JOptionPane.YES_OPTION){
                        ((DefaultTableModel)table.getModel()).removeRow(row);
                        MyDB.bin.remove(record.id);
                    }
                    else{
                        record.count++;
                    }
                }
                else {
                    table.getModel().setValueAt(record.count, row, 5);
                    MyDB.bin.put(record.id, record);
                }

            }
        });

        fileNameField = new JTextField();

        labelNameField = new JLabel("Путь к файлу:");

        panelButton.add(returnButton);
        panelButton.add(plusButton);
        panelButton.add(minusButton);

        panelButton.add(labelNameField);
        panelButton.add(fileNameField);
        panelButton.add(pokupkaButton);
        tableBin();
        panelMain.add(panelButton, BorderLayout.LINE_START);
        panelMain.add(panelTable, BorderLayout.CENTER);
        this.add(panelMain);
    }

    public void showBin(DefaultTableModel model) {
        for(Map.Entry<Integer, Record> entry: MyDB.bin.entrySet()){
            Record record = entry.getValue();
            model.addRow(new Object[] {record.id, record.brand, record.category, record.modelName, record.price, record.count});
        }
    }

    public void tableBin(){
        panelTable = new JPanel();
        DefaultTableModel model = new DefaultTableModel();
        String[] columns = {"ID", "Бренд", "Категория","Модель", "Цена", "Количество"};
        model.setColumnIdentifiers(columns);
        table = new JTable();
        table.setModel(model);
        showBin(model);
        panelTable.setLayout(new BorderLayout());
        panelTable.add(new JScrollPane(table), BorderLayout.CENTER);
    }

}
