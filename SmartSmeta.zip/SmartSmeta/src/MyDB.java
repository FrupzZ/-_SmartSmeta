import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

public class MyDB {
    public static HashMap <Integer, Record> bin = new HashMap<>();

    private static String URL = "jdbc:mysql://localhost/smartsmeta";
    private static String driver = "com.mysql.jdbc.Driver";
    private static String user = "root";
    private static String password = "R1ckavenger!";
    private static Connection con = null;

    public static Connection getCon() throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        if(con == null){
                Class.forName(driver).newInstance();
                con = DriverManager.getConnection(URL, user, password);
                System.out.println("Sucsesful connection");
        }
        return con;
    }
}
