import javax.accessibility.Accessible;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Register extends JFrame {
    private JPanel panelMain;
    private JPanel panelButton;
    private JPanel panelLabel;
    private JLabel nameLabel;
    private JLabel passwordLabel;
    private JLabel confirmPasswdLabel;
    private JButton registerButton;
    private JButton cancelButton;
    private JTextField loginField;
    private JTextField passwordField;
    private JTextField confirmField;
    public Register(){
        this.setSize(500,300);
        this.setLocationRelativeTo(null);
        this.setTitle("Регистрация");
        JFrame frame = new JFrame();
        panelMain = new JPanel();
        panelMain.setLayout(new BoxLayout(panelMain, BoxLayout.Y_AXIS));

        GridBagLayout layout = new GridBagLayout();
        panelLabel = new JPanel(layout);
        GridBagConstraints constraints = new GridBagConstraints();
        panelMain.add(panelLabel);

        panelButton = new JPanel();

        nameLabel = new JLabel("Логин");
        constraints.weightx = 0.3;
        constraints.fill = GridBagConstraints.NONE;
        constraints.gridx = 0;
        constraints.gridy = 0;
        panelLabel.add(nameLabel, constraints);

        passwordLabel = new JLabel("Пароль");
        constraints.weightx = 0.3;
        constraints.insets = new Insets(10, 0, 0, 0);
        constraints.fill = GridBagConstraints.NONE;
        constraints.gridx = 0;
        constraints.gridy = 1;
        panelLabel.add(passwordLabel, constraints);

        confirmPasswdLabel = new JLabel("Повторите пароль");
        constraints.weightx = 0.3;
        constraints.insets = new Insets(10, 0, 0, 0);
        constraints.fill = GridBagConstraints.NONE;
        constraints.gridx = 0;
        constraints.gridy = 2;
        panelLabel.add(confirmPasswdLabel, constraints);

        loginField = new JTextField();
        loginField.setColumns(10);
        constraints.weightx = 0.7;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 0;
        panelLabel.add(loginField, constraints);

        passwordField = new JTextField();
        passwordField.setColumns(10);
        constraints.insets = new Insets(10, 0, 0, 0);
        constraints.weightx = 0.7;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 1;
        panelLabel.add(passwordField, constraints);

        confirmField = new JTextField();
        confirmField.setColumns(10);
        constraints.insets = new Insets(10, 0, 0, 0);
        constraints.weightx = 0.7;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 2;
        panelLabel.add(confirmField, constraints);

        registerButton = new JButton("Зарегистрироваться");
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean isCorrect = true;

                if (!(passwordField.getText().equals(confirmField.getText()))){
                    // подтверждение, что пароли не равны
                    JOptionPane.showMessageDialog(Register.this,
                            "Пароли не совпадают",
                            "Ошибка",
                            JOptionPane.ERROR_MESSAGE);
                    isCorrect = false;
                }
                if (!(passwordField.getText().length() >= 5)) {
                    JOptionPane.showMessageDialog(Register.this,
                            "Пароль должен быть более 4 символов",
                            "Ошибка",
                            JOptionPane.ERROR_MESSAGE);
                    isCorrect = false;
                }
                if (!(passwordField.getText().length() <= 10)){
                    JOptionPane.showMessageDialog(Register.this,
                            "Пароль должен быть менее 10 символов",
                            "Ошибка",
                            JOptionPane.ERROR_MESSAGE);
                    isCorrect = false;
                }
                    String password = passwordField.getText();
                    int res0 = password.indexOf('0');
                    int res1 = password.indexOf('1');
                    int res2 = password.indexOf('2');
                    int res3 = password.indexOf('3');
                    int res4 = password.indexOf('4');
                    int res5 = password.indexOf('5');
                    int res6 = password.indexOf('6');
                    int res7 = password.indexOf('7');
                    int res8 = password.indexOf('8');
                    int res9 = password.indexOf('9');

                    if (!(res0 >= 0 || res1 >= 0 || res2 >= 0 || res3 >= 0 || res4 >= 0 || res5 >= 0 || res6 >= 0 || res7 >= 0 || res8 >= 0 || res9 >= 0)) {
                        JOptionPane.showMessageDialog(Register.this,
                                "Должна быть хотя бы 1 цифра",
                                "Ошибка",
                                JOptionPane.ERROR_MESSAGE);
                        isCorrect = false;
                    }

                String login = loginField.getText();
                boolean checkLoginDB = false;
                try {
                    checkLoginDB = checkLoginDB(login);
                    if (checkLoginDB == true){
                        JOptionPane.showMessageDialog(Register.this,
                                "Такой пользователь уже зарегистрирован",
                                "Ошибка",
                                JOptionPane.ERROR_MESSAGE);
                        isCorrect = false;
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(Register.this,
                            "Ошибка преобращения к базе данных",
                            "Ошибка",
                            JOptionPane.ERROR_MESSAGE);
                    isCorrect = false;
                }
                if (isCorrect == true){
                    try{
                        newUserDB(login, password);
                        //После создания аккаунта отправляет обратно к Login
                        Login log = new Login();
                        log.setVisible(true);
                        dispatchEvent(new WindowEvent(Register.this, WindowEvent.WINDOW_CLOSING));
                    }
                    catch (Exception exc){
                        JOptionPane.showMessageDialog(Register.this,
                                "Ошибка преобращения к базе данных",
                                "Ошибка",
                                JOptionPane.ERROR_MESSAGE);
                        isCorrect = false;
                    }
                }
            }
        });

        panelButton.setLayout(new BoxLayout(panelButton, BoxLayout.X_AXIS));
        registerButton.setAlignmentY(Component.BOTTOM_ALIGNMENT);
        registerButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
        cancelButton = new JButton("Отмена");
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //возвращает к форме Login
                Login log = new Login();
                log.setVisible(true);
                dispatchEvent(new WindowEvent(Register.this, WindowEvent.WINDOW_CLOSING));
            }
        });
        cancelButton.setAlignmentY(Component.BOTTOM_ALIGNMENT);
        cancelButton.setAlignmentX(Component.RIGHT_ALIGNMENT);
        panelButton.add(registerButton);
        panelButton.add(cancelButton);
        panelMain.add(panelButton);
        this.add(panelMain);
    }

    public boolean checkLoginDB(String login) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        String query = "SELECT * FROM users WHERE login = '" + login + "';";
        Connection connect = MyDB.getCon();
        if (connect != null){
            Statement st = null;
            st = connect.createStatement();
            ResultSet result = st.executeQuery(query);
            if (result.next()){
                return true;
            }
        }
        return false;
    }

    public void newUserDB(String login, String password) throws SQLException, ClassNotFoundException, InstantiationException, IllegalAccessException{
        String query = "INSERT INTO users (login, password) VALUES ('" + login + "', '" + password +"');";
        Connection connect = MyDB.getCon();
        if (connect != null){
            Statement st = connect.createStatement();
            int rowCount = st.executeUpdate(query);
        }
        else{
            throw new SQLException();
        }
    }
}
